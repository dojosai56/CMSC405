import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.*;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.glu.GLUquadric;


public class HexagonalPrism extends GLJPanel implements GLEventListener, KeyListener {
    
    /**
     * A main routine to create and show a window that contains a
     * panel of type Hexagonal Prism.  The program ends when the
     * user closes the window.
     */
    public static void main(String[] args) {
        JFrame window = new JFrame("A Hexagonal Prism -- ARROW KEYS ROTATE");
        HexagonalPrism panel = new HexagonalPrism();
        window.setContentPane(panel);
        window.pack();
        window.setLocation(50,50);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
        panel.requestFocusInWindow();
    }
    
    /**
     * Constructor for class HexagonalPrism.
     */
    public HexagonalPrism() {
        super( new GLCapabilities(null) ); // Makes a panel with default OpenGL "capabilities".
        setPreferredSize( new Dimension(640,480) );
        addGLEventListener(this); // A listener is essential! The listener is where the OpenGL programming lives.
        addKeyListener(this);
    }
    
    //-------------------- methods to draw the Hexagonal Prism ----------------------
    
    double rotateX = 15;    // rotations of the Hexagonal Prism about the axes
    double rotateY = -15;
    double rotateZ = 0;
    double translateX = 0, translateY = 0, translateZ = 0;
    
    
    // hexagonal prism
    private void hexagonalPrism(GL2 gl2, double size) {
    	//final GL2 gl = drawable.getGL().getGL2();
	    	   gl2.glScaled(0.3,0.3,0.3);
	    	   gl2.glColor3d(0,1,1);
	    	   gl2.glBegin(GL2.GL_POLYGON);
	    	   gl2.glVertex3d(0,0.5,0);
	    	   gl2.glVertex3d(-0.5,0.2,0);
	    	   gl2.glVertex3d(-0.5,-0.2,0);
	    	   gl2.glVertex3d(0,-0.5,0);
	    	   gl2.glVertex3d(0,0.5,0);
	    	   gl2.glVertex3d(0.5,0.2,0);
	    	   gl2.glVertex3d(0.5,-0.2,0);
	    	   gl2.glVertex3d(0,-0.5,0);
	    	   gl2.glEnd();
	    	   
	    	   gl2.glColor3d(1,0,0);
	    	   gl2.glBegin(GL2.GL_POLYGON);
	    	   gl2.glVertex3d(0,0.5,0.7);
	    	   gl2.glVertex3d(-0.5,0.2,0.7);
	    	   gl2.glVertex3d(-0.5,-0.2,0.7);
	    	   gl2.glVertex3d(0,-0.5,0.7);
	    	   gl2.glVertex3d(0,0.5,0.7);
	    	   gl2.glVertex3d(0.5,0.2,0.7);
	    	   gl2.glVertex3d(0.5,-0.2,0.7);
	    	   gl2.glVertex3d(0,-0.5,0.7);
	    	   gl2.glEnd();
	    	   
	    	   gl2.glColor3d(1, 0, 1);
	   		gl2.glBegin(GL2.GL_POLYGON);
	   		gl2.glVertex3d(0, 0.5, 0);
	   		gl2.glVertex3d(-0.5, 0.2, 0);
	   		gl2.glVertex3d(-0.5, 0.2, 0.7);
	   		gl2.glVertex3d(0, 0.5, 0.7);
	   		gl2.glEnd();
	
	   		gl2.glColor3d(1, .5, 0);
	   		gl2.glBegin(GL2.GL_POLYGON);
	   		gl2.glVertex3d(-0.5, -0.2, 0);
	   		gl2.glVertex3d(0, -0.5, 0);
	   		gl2.glVertex3d(0, -0.5, 0.7);
	   		gl2.glVertex3d(-0.5, -0.2, 0.7);
	   		gl2.glEnd();
	   		
	   		gl2.glColor3d(0.5, 0, 1);
	   		gl2.glBegin(GL2.GL_POLYGON);
	   		gl2.glVertex3d(0, 0.5, 0);
	   		gl2.glVertex3d(0.5, 0.2, 0);
	   		gl2.glVertex3d(0.5, 0.2, 0.7);
	   		gl2.glVertex3d(0, 0.5, 0.7);
	   		gl2.glEnd();
	   		
	   		gl2.glColor3d(0, 1, 0);
	   		gl2.glBegin(GL2.GL_POLYGON);
	   		gl2.glVertex3d(0.5, -0.2, 0);
	   		gl2.glVertex3d(0, -0.5, 0);
	   		gl2.glVertex3d(0, -0.5, 0.7);
	   		gl2.glVertex3d(0.5, -0.2, 0.7);
	   		gl2.glEnd();
	   		
	   		gl2.glColor3d(0, 0.5, 0);
	   		gl2.glBegin(GL2.GL_POLYGON);
	   		gl2.glVertex3d(0, -0.5, 0);
	   		gl2.glVertex3d(0, 0.5, 0);
	   		gl2.glVertex3d(0, 0.5, 0.7);
	   		gl2.glVertex3d(0, -0.5, 0.7);
	   		gl2.glEnd();
	   		
	
	   		gl2.glColor3d(0.5, 0.5, 0);
	   		gl2.glBegin(GL2.GL_POLYGON);
	   		gl2.glVertex3d(-0.5, 0.2, 0);
	   		gl2.glVertex3d(-0.5, -0.2, 0);
	   		gl2.glVertex3d(-0.5, -0.2, 0.7);
	   		gl2.glVertex3d(-0.5, 0.2, 0.7);	
	   		gl2.glEnd();
	   		
	   		gl2.glColor3d(1, 1, 1);
	   		gl2.glBegin(GL2.GL_POLYGON);
	   		gl2.glVertex3d(0, -0.5, 0);
	   		gl2.glVertex3d(0, 0.5, 0);
	   		gl2.glVertex3d(0, 0.5, 0.7);
	   		gl2.glVertex3d(0.5, 0.2, 0.7);
	   		gl2.glEnd();
    	   
    }
    //-------------------- GLEventListener Methods -------------------------

    /**
     * The display method is called when the panel needs to be redrawn.
     * The is where the code goes for drawing the image, using OpenGL commands.
     */
    public void display(GLAutoDrawable drawable) {    
        
        GL2 gl2 = drawable.getGL().getGL2(); // The object that contains all the OpenGL methods.
         
        gl2.glClear( GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT );
        
        gl2.glLoadIdentity();             // Set up modelview transform. 
        gl2.glRotated(rotateZ,0,0,1);
        gl2.glRotated(rotateY,0,1,0);
        gl2.glRotated(rotateX,1,0,0);

        gl2.glTranslated(translateX, translateY, translateZ);
        hexagonalPrism(gl2, 1);
        
        
    } // end display()

    public void init(GLAutoDrawable drawable) {
           // called when the panel is created
        GL2 gl2 = drawable.getGL().getGL2();
        gl2.glMatrixMode(GL2.GL_PROJECTION);
        gl2.glOrtho(-1, 1 ,-1, 1, -1, 1);
        gl2.glMatrixMode(GL2.GL_MODELVIEW);
        gl2.glClearColor( 0, 0, 0, 1 );
        gl2.glEnable(GL2.GL_DEPTH_TEST);
    }

    public void dispose(GLAutoDrawable drawable) {
            // called when the panel is being disposed
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
            // called when user resizes the window
    }
    
    // ----------------  Methods from the KeyListener interface --------------

    public void keyPressed(KeyEvent evt) {
        int key = evt.getKeyCode();
        if ( key == KeyEvent.VK_LEFT )
            rotateY -= 15;
         else if ( key == KeyEvent.VK_RIGHT )
            rotateY += 15;
         else if ( key == KeyEvent.VK_DOWN)
            rotateX += 15;
         else if ( key == KeyEvent.VK_UP )
            rotateX -= 15;
         else if ( key == KeyEvent.VK_PAGE_UP )
            rotateZ += 15;
         else if ( key == KeyEvent.VK_PAGE_DOWN )
            rotateZ -= 15;
         else if ( key == KeyEvent.VK_HOME )
            rotateX = rotateY = rotateZ = 0;
         else if ( key == KeyEvent.VK_W )
        	 translateY += 1;
         else if ( key == KeyEvent.VK_S )
        	 translateY -= 1;
         else if ( key == KeyEvent.VK_A )
        	 translateX -= 1;
         else if ( key == KeyEvent.VK_D )
        	 translateX += 1;
         else if ( key == KeyEvent.VK_I )
        	 translateZ -= 1;
         else if ( key == KeyEvent.VK_O )
        	 translateZ += 1;
         
                repaint();
    }

    public void keyReleased(KeyEvent evt) {
    }
    
    public void keyTyped(KeyEvent evt) {
    }
    
}
